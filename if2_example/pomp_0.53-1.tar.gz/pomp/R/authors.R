list(
     aak=person(given=c("Aaron","A."),family="King",role=c("aut","cre"),email="kingaa@umich.edu"),
     eli=person(given=c("Edward","L."),family="Ionides",role=c("ctb")),
     cb=person(given=c("Carles"),family="Breto",role=c("ctb")),
     spe=person(given=c("Stephen","P."),family="Ellner",role=c("ctb")),
     bek=person(given=c("Bruce","E."),family="Kendall",role=c("ctb")),
     mf=person(given=c("Matthew","J."),family="Ferrari",role=c("ctb")),
     ml=person(given=c("Michael"),family="Lavine",role=c("ctb")),
     dcr=person(given=c("Daniel","C."),family="Reuman",role=c("ctb")),
     hw=person(given=c("Helen"),family="Wearing",role=c("ctb")),
     snw=person(given=c("Simon","N."),family="Wood",role=c("ctb"))
     ) -> author.list
